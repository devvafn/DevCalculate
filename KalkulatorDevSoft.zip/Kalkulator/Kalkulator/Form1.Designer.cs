namespace Kalkulator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.CircleProgressbar1 = new Bunifu.Framework.UI.BunifuCircleProgressbar();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Label3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.ImageButton2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.ImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.Tan = new System.Windows.Forms.Button();
            this.Log = new System.Windows.Forms.Button();
            this.Cos = new System.Windows.Forms.Button();
            this.Sin = new System.Windows.Forms.Button();
            this.clsamadengan = new Bunifu.Framework.UI.BunifuImageButton();
            this.clkali = new Bunifu.Framework.UI.BunifuImageButton();
            this.clminus = new Bunifu.Framework.UI.BunifuImageButton();
            this.clplus = new Bunifu.Framework.UI.BunifuImageButton();
            this.clbagi = new Bunifu.Framework.UI.BunifuImageButton();
            this.cldot = new Bunifu.Framework.UI.BunifuImageButton();
            this.clpersen = new Bunifu.Framework.UI.BunifuImageButton();
            this.clhapus = new Bunifu.Framework.UI.BunifuImageButton();
            this.clclear = new Bunifu.Framework.UI.BunifuImageButton();
            this.clplusminus = new Bunifu.Framework.UI.BunifuImageButton();
            this.cl8 = new Bunifu.Framework.UI.BunifuImageButton();
            this.cl9 = new Bunifu.Framework.UI.BunifuImageButton();
            this.cl7 = new Bunifu.Framework.UI.BunifuImageButton();
            this.cl3 = new Bunifu.Framework.UI.BunifuImageButton();
            this.cl4 = new Bunifu.Framework.UI.BunifuImageButton();
            this.cl0 = new Bunifu.Framework.UI.BunifuImageButton();
            this.cl1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.cl2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.cl5 = new Bunifu.Framework.UI.BunifuImageButton();
            this.cl6 = new Bunifu.Framework.UI.BunifuImageButton();
            this.tbhasil = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Label4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImageButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clsamadengan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clkali)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clminus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clplus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clbagi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cldot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clpersen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clhapus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clclear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clplusminus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl6)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(120)))), ((int)(((byte)(204)))));
            this.panel1.Controls.Add(this.CircleProgressbar1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.Label3);
            this.panel1.Controls.Add(this.Label2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(447, 87);
            this.panel1.TabIndex = 0;
            // 
            // CircleProgressbar1
            // 
            this.CircleProgressbar1.animated = true;
            this.CircleProgressbar1.animationIterval = 10;
            this.CircleProgressbar1.animationSpeed = 100;
            this.CircleProgressbar1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(120)))), ((int)(((byte)(204)))));
            this.CircleProgressbar1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("CircleProgressbar1.BackgroundImage")));
            this.CircleProgressbar1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F);
            this.CircleProgressbar1.ForeColor = System.Drawing.Color.SeaGreen;
            this.CircleProgressbar1.LabelVisible = false;
            this.CircleProgressbar1.LineProgressThickness = 3;
            this.CircleProgressbar1.LineThickness = 2;
            this.CircleProgressbar1.Location = new System.Drawing.Point(1, 48);
            this.CircleProgressbar1.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.CircleProgressbar1.MaxValue = 100;
            this.CircleProgressbar1.Name = "CircleProgressbar1";
            this.CircleProgressbar1.ProgressBackColor = System.Drawing.Color.Gainsboro;
            this.CircleProgressbar1.ProgressColor = System.Drawing.Color.White;
            this.CircleProgressbar1.Size = new System.Drawing.Size(40, 40);
            this.CircleProgressbar1.TabIndex = 4;
            this.CircleProgressbar1.Value = 50;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(335, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(90, 70);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Revel Light", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.ForeColor = System.Drawing.Color.White;
            this.Label3.Location = new System.Drawing.Point(3, 3);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(87, 25);
            this.Label3.TabIndex = 1;
            this.Label3.Text = "Calculator";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("GeosansLight", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.White;
            this.Label2.Location = new System.Drawing.Point(130, 28);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(151, 39);
            this.Label2.TabIndex = 0;
            this.Label2.Text = "Welcome";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Malgun Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.ForeColor = System.Drawing.Color.Black;
            this.Label5.Location = new System.Drawing.Point(371, 353);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(74, 15);
            this.Label5.TabIndex = 2;
            this.Label5.Text = "By : @d_vyd";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.Label5);
            this.panel2.Controls.Add(this.ImageButton2);
            this.panel2.Controls.Add(this.ImageButton1);
            this.panel2.Controls.Add(this.Tan);
            this.panel2.Controls.Add(this.Log);
            this.panel2.Controls.Add(this.Cos);
            this.panel2.Controls.Add(this.Sin);
            this.panel2.Controls.Add(this.clsamadengan);
            this.panel2.Controls.Add(this.clkali);
            this.panel2.Controls.Add(this.clminus);
            this.panel2.Controls.Add(this.clplus);
            this.panel2.Controls.Add(this.clbagi);
            this.panel2.Controls.Add(this.cldot);
            this.panel2.Controls.Add(this.clpersen);
            this.panel2.Controls.Add(this.clhapus);
            this.panel2.Controls.Add(this.clclear);
            this.panel2.Controls.Add(this.clplusminus);
            this.panel2.Controls.Add(this.cl8);
            this.panel2.Controls.Add(this.cl9);
            this.panel2.Controls.Add(this.cl7);
            this.panel2.Controls.Add(this.cl3);
            this.panel2.Controls.Add(this.cl4);
            this.panel2.Controls.Add(this.cl0);
            this.panel2.Controls.Add(this.cl1);
            this.panel2.Controls.Add(this.cl2);
            this.panel2.Controls.Add(this.cl5);
            this.panel2.Controls.Add(this.cl6);
            this.panel2.Controls.Add(this.tbhasil);
            this.panel2.Location = new System.Drawing.Point(0, 87);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(447, 371);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(39)))), ((int)(((byte)(176)))));
            this.button1.Location = new System.Drawing.Point(11, 16);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(45, 25);
            this.button1.TabIndex = 41;
            this.button1.Text = "Copy";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // ImageButton2
            // 
            this.ImageButton2.BackColor = System.Drawing.Color.Transparent;
            this.ImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("ImageButton2.Image")));
            this.ImageButton2.ImageActive = null;
            this.ImageButton2.Location = new System.Drawing.Point(391, 112);
            this.ImageButton2.Name = "ImageButton2";
            this.ImageButton2.Size = new System.Drawing.Size(50, 45);
            this.ImageButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ImageButton2.TabIndex = 40;
            this.ImageButton2.TabStop = false;
            this.ImageButton2.Zoom = 10;
            this.ImageButton2.Click += new System.EventHandler(this.ImageButton2_Click_1);
            // 
            // ImageButton1
            // 
            this.ImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.ImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("ImageButton1.Image")));
            this.ImageButton1.ImageActive = null;
            this.ImageButton1.Location = new System.Drawing.Point(335, 112);
            this.ImageButton1.Name = "ImageButton1";
            this.ImageButton1.Size = new System.Drawing.Size(50, 45);
            this.ImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ImageButton1.TabIndex = 39;
            this.ImageButton1.TabStop = false;
            this.ImageButton1.Zoom = 10;
            this.ImageButton1.Click += new System.EventHandler(this.ImageButton1_Click_1);
            // 
            // Tan
            // 
            this.Tan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(39)))), ((int)(((byte)(176)))));
            this.Tan.Location = new System.Drawing.Point(279, 112);
            this.Tan.Name = "Tan";
            this.Tan.Size = new System.Drawing.Size(50, 45);
            this.Tan.TabIndex = 38;
            this.Tan.Text = "Tan";
            this.Tan.UseVisualStyleBackColor = true;
            this.Tan.Click += new System.EventHandler(this.Tan_Click);
            // 
            // Log
            // 
            this.Log.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(39)))), ((int)(((byte)(176)))));
            this.Log.Location = new System.Drawing.Point(391, 61);
            this.Log.Name = "Log";
            this.Log.Size = new System.Drawing.Size(50, 45);
            this.Log.TabIndex = 37;
            this.Log.Text = "Log";
            this.Log.UseVisualStyleBackColor = true;
            this.Log.Click += new System.EventHandler(this.Log_Click);
            // 
            // Cos
            // 
            this.Cos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(39)))), ((int)(((byte)(176)))));
            this.Cos.Location = new System.Drawing.Point(335, 61);
            this.Cos.Name = "Cos";
            this.Cos.Size = new System.Drawing.Size(50, 45);
            this.Cos.TabIndex = 36;
            this.Cos.Text = "Cos";
            this.Cos.UseVisualStyleBackColor = true;
            this.Cos.Click += new System.EventHandler(this.Cos_Click);
            // 
            // Sin
            // 
            this.Sin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(39)))), ((int)(((byte)(176)))));
            this.Sin.Location = new System.Drawing.Point(279, 61);
            this.Sin.Name = "Sin";
            this.Sin.Size = new System.Drawing.Size(50, 45);
            this.Sin.TabIndex = 0;
            this.Sin.Text = "Sin";
            this.Sin.UseVisualStyleBackColor = true;
            this.Sin.Click += new System.EventHandler(this.Sin_Click);
            // 
            // clsamadengan
            // 
            this.clsamadengan.BackColor = System.Drawing.Color.Transparent;
            this.clsamadengan.Image = ((System.Drawing.Image)(resources.GetObject("clsamadengan.Image")));
            this.clsamadengan.ImageActive = null;
            this.clsamadengan.Location = new System.Drawing.Point(197, 300);
            this.clsamadengan.Name = "clsamadengan";
            this.clsamadengan.Size = new System.Drawing.Size(60, 60);
            this.clsamadengan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.clsamadengan.TabIndex = 30;
            this.clsamadengan.TabStop = false;
            this.clsamadengan.Zoom = 10;
            this.clsamadengan.Click += new System.EventHandler(this.clsamadengan_Click);
            // 
            // clkali
            // 
            this.clkali.BackColor = System.Drawing.Color.Transparent;
            this.clkali.Image = ((System.Drawing.Image)(resources.GetObject("clkali.Image")));
            this.clkali.ImageActive = null;
            this.clkali.Location = new System.Drawing.Point(197, 121);
            this.clkali.Name = "clkali";
            this.clkali.Size = new System.Drawing.Size(60, 60);
            this.clkali.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.clkali.TabIndex = 29;
            this.clkali.TabStop = false;
            this.clkali.Zoom = 10;
            this.clkali.Click += new System.EventHandler(this.clkali_Click);
            // 
            // clminus
            // 
            this.clminus.BackColor = System.Drawing.Color.Transparent;
            this.clminus.Image = ((System.Drawing.Image)(resources.GetObject("clminus.Image")));
            this.clminus.ImageActive = null;
            this.clminus.Location = new System.Drawing.Point(197, 181);
            this.clminus.Name = "clminus";
            this.clminus.Size = new System.Drawing.Size(60, 60);
            this.clminus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.clminus.TabIndex = 28;
            this.clminus.TabStop = false;
            this.clminus.Zoom = 10;
            this.clminus.Click += new System.EventHandler(this.clminus_Click);
            // 
            // clplus
            // 
            this.clplus.BackColor = System.Drawing.Color.Transparent;
            this.clplus.Image = ((System.Drawing.Image)(resources.GetObject("clplus.Image")));
            this.clplus.ImageActive = null;
            this.clplus.Location = new System.Drawing.Point(197, 241);
            this.clplus.Name = "clplus";
            this.clplus.Size = new System.Drawing.Size(60, 60);
            this.clplus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.clplus.TabIndex = 27;
            this.clplus.TabStop = false;
            this.clplus.Zoom = 10;
            this.clplus.Click += new System.EventHandler(this.clplus_Click);
            // 
            // clbagi
            // 
            this.clbagi.BackColor = System.Drawing.Color.Transparent;
            this.clbagi.Image = ((System.Drawing.Image)(resources.GetObject("clbagi.Image")));
            this.clbagi.ImageActive = null;
            this.clbagi.Location = new System.Drawing.Point(137, 61);
            this.clbagi.Name = "clbagi";
            this.clbagi.Size = new System.Drawing.Size(60, 60);
            this.clbagi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.clbagi.TabIndex = 26;
            this.clbagi.TabStop = false;
            this.clbagi.Zoom = 10;
            this.clbagi.Click += new System.EventHandler(this.clbagi_Click);
            // 
            // cldot
            // 
            this.cldot.BackColor = System.Drawing.Color.Transparent;
            this.cldot.Image = ((System.Drawing.Image)(resources.GetObject("cldot.Image")));
            this.cldot.ImageActive = null;
            this.cldot.Location = new System.Drawing.Point(152, 327);
            this.cldot.Name = "cldot";
            this.cldot.Size = new System.Drawing.Size(30, 30);
            this.cldot.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.cldot.TabIndex = 24;
            this.cldot.TabStop = false;
            this.cldot.Zoom = 10;
            this.cldot.Click += new System.EventHandler(this.cldot_Click);
            // 
            // clpersen
            // 
            this.clpersen.BackColor = System.Drawing.Color.Transparent;
            this.clpersen.Image = ((System.Drawing.Image)(resources.GetObject("clpersen.Image")));
            this.clpersen.ImageActive = null;
            this.clpersen.Location = new System.Drawing.Point(77, 61);
            this.clpersen.Name = "clpersen";
            this.clpersen.Size = new System.Drawing.Size(60, 60);
            this.clpersen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.clpersen.TabIndex = 23;
            this.clpersen.TabStop = false;
            this.clpersen.Zoom = 10;
            this.clpersen.Click += new System.EventHandler(this.clpersen_Click);
            // 
            // clhapus
            // 
            this.clhapus.BackColor = System.Drawing.Color.Transparent;
            this.clhapus.Image = ((System.Drawing.Image)(resources.GetObject("clhapus.Image")));
            this.clhapus.ImageActive = null;
            this.clhapus.Location = new System.Drawing.Point(197, 61);
            this.clhapus.Name = "clhapus";
            this.clhapus.Size = new System.Drawing.Size(60, 60);
            this.clhapus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.clhapus.TabIndex = 22;
            this.clhapus.TabStop = false;
            this.clhapus.Zoom = 10;
            // 
            // clclear
            // 
            this.clclear.BackColor = System.Drawing.Color.Transparent;
            this.clclear.Image = ((System.Drawing.Image)(resources.GetObject("clclear.Image")));
            this.clclear.ImageActive = null;
            this.clclear.Location = new System.Drawing.Point(17, 61);
            this.clclear.Name = "clclear";
            this.clclear.Size = new System.Drawing.Size(60, 60);
            this.clclear.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.clclear.TabIndex = 21;
            this.clclear.TabStop = false;
            this.clclear.Zoom = 10;
            this.clclear.Click += new System.EventHandler(this.clclear_Click);
            // 
            // clplusminus
            // 
            this.clplusminus.BackColor = System.Drawing.Color.Transparent;
            this.clplusminus.Image = ((System.Drawing.Image)(resources.GetObject("clplusminus.Image")));
            this.clplusminus.ImageActive = null;
            this.clplusminus.Location = new System.Drawing.Point(17, 300);
            this.clplusminus.Name = "clplusminus";
            this.clplusminus.Size = new System.Drawing.Size(60, 60);
            this.clplusminus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.clplusminus.TabIndex = 20;
            this.clplusminus.TabStop = false;
            this.clplusminus.Zoom = 10;
            this.clplusminus.Click += new System.EventHandler(this.clplusminus_Click);
            // 
            // cl8
            // 
            this.cl8.BackColor = System.Drawing.Color.Transparent;
            this.cl8.Image = ((System.Drawing.Image)(resources.GetObject("cl8.Image")));
            this.cl8.ImageActive = null;
            this.cl8.Location = new System.Drawing.Point(77, 121);
            this.cl8.Name = "cl8";
            this.cl8.Size = new System.Drawing.Size(60, 60);
            this.cl8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cl8.TabIndex = 19;
            this.cl8.TabStop = false;
            this.cl8.Zoom = 10;
            this.cl8.Click += new System.EventHandler(this.cl8_Click);
            // 
            // cl9
            // 
            this.cl9.BackColor = System.Drawing.Color.Transparent;
            this.cl9.Image = ((System.Drawing.Image)(resources.GetObject("cl9.Image")));
            this.cl9.ImageActive = null;
            this.cl9.Location = new System.Drawing.Point(137, 121);
            this.cl9.Name = "cl9";
            this.cl9.Size = new System.Drawing.Size(60, 60);
            this.cl9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cl9.TabIndex = 18;
            this.cl9.TabStop = false;
            this.cl9.Zoom = 10;
            this.cl9.Click += new System.EventHandler(this.cl9_Click);
            // 
            // cl7
            // 
            this.cl7.BackColor = System.Drawing.Color.Transparent;
            this.cl7.Image = ((System.Drawing.Image)(resources.GetObject("cl7.Image")));
            this.cl7.ImageActive = null;
            this.cl7.Location = new System.Drawing.Point(17, 121);
            this.cl7.Name = "cl7";
            this.cl7.Size = new System.Drawing.Size(60, 60);
            this.cl7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cl7.TabIndex = 17;
            this.cl7.TabStop = false;
            this.cl7.Zoom = 10;
            this.cl7.Click += new System.EventHandler(this.cl7_Click);
            // 
            // cl3
            // 
            this.cl3.BackColor = System.Drawing.Color.Transparent;
            this.cl3.Image = ((System.Drawing.Image)(resources.GetObject("cl3.Image")));
            this.cl3.ImageActive = null;
            this.cl3.Location = new System.Drawing.Point(137, 241);
            this.cl3.Name = "cl3";
            this.cl3.Size = new System.Drawing.Size(60, 60);
            this.cl3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cl3.TabIndex = 14;
            this.cl3.TabStop = false;
            this.cl3.Zoom = 10;
            this.cl3.Click += new System.EventHandler(this.cl3_Click);
            // 
            // cl4
            // 
            this.cl4.BackColor = System.Drawing.Color.Transparent;
            this.cl4.Image = ((System.Drawing.Image)(resources.GetObject("cl4.Image")));
            this.cl4.ImageActive = null;
            this.cl4.Location = new System.Drawing.Point(17, 181);
            this.cl4.Name = "cl4";
            this.cl4.Size = new System.Drawing.Size(60, 60);
            this.cl4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cl4.TabIndex = 7;
            this.cl4.TabStop = false;
            this.cl4.Zoom = 10;
            this.cl4.Click += new System.EventHandler(this.cl4_Click);
            // 
            // cl0
            // 
            this.cl0.BackColor = System.Drawing.Color.Transparent;
            this.cl0.Image = ((System.Drawing.Image)(resources.GetObject("cl0.Image")));
            this.cl0.ImageActive = null;
            this.cl0.Location = new System.Drawing.Point(77, 300);
            this.cl0.Name = "cl0";
            this.cl0.Size = new System.Drawing.Size(60, 60);
            this.cl0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.cl0.TabIndex = 5;
            this.cl0.TabStop = false;
            this.cl0.Zoom = 10;
            this.cl0.Click += new System.EventHandler(this.cl0_Click);
            // 
            // cl1
            // 
            this.cl1.BackColor = System.Drawing.Color.Transparent;
            this.cl1.Image = ((System.Drawing.Image)(resources.GetObject("cl1.Image")));
            this.cl1.ImageActive = null;
            this.cl1.Location = new System.Drawing.Point(17, 241);
            this.cl1.Name = "cl1";
            this.cl1.Size = new System.Drawing.Size(60, 60);
            this.cl1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cl1.TabIndex = 6;
            this.cl1.TabStop = false;
            this.cl1.Zoom = 10;
            this.cl1.Click += new System.EventHandler(this.cl1_Click);
            // 
            // cl2
            // 
            this.cl2.BackColor = System.Drawing.Color.Transparent;
            this.cl2.Image = ((System.Drawing.Image)(resources.GetObject("cl2.Image")));
            this.cl2.ImageActive = null;
            this.cl2.Location = new System.Drawing.Point(77, 241);
            this.cl2.Name = "cl2";
            this.cl2.Size = new System.Drawing.Size(60, 60);
            this.cl2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cl2.TabIndex = 4;
            this.cl2.TabStop = false;
            this.cl2.Zoom = 10;
            this.cl2.Click += new System.EventHandler(this.cl2_Click);
            // 
            // cl5
            // 
            this.cl5.BackColor = System.Drawing.Color.Transparent;
            this.cl5.Image = ((System.Drawing.Image)(resources.GetObject("cl5.Image")));
            this.cl5.ImageActive = null;
            this.cl5.Location = new System.Drawing.Point(77, 181);
            this.cl5.Name = "cl5";
            this.cl5.Size = new System.Drawing.Size(60, 60);
            this.cl5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cl5.TabIndex = 3;
            this.cl5.TabStop = false;
            this.cl5.Zoom = 10;
            this.cl5.Click += new System.EventHandler(this.cl5_Click);
            // 
            // cl6
            // 
            this.cl6.BackColor = System.Drawing.Color.Transparent;
            this.cl6.Image = ((System.Drawing.Image)(resources.GetObject("cl6.Image")));
            this.cl6.ImageActive = null;
            this.cl6.Location = new System.Drawing.Point(137, 181);
            this.cl6.Name = "cl6";
            this.cl6.Size = new System.Drawing.Size(60, 60);
            this.cl6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cl6.TabIndex = 2;
            this.cl6.TabStop = false;
            this.cl6.Zoom = 10;
            this.cl6.Click += new System.EventHandler(this.cl6_Click);
            // 
            // tbhasil
            // 
            this.tbhasil.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.tbhasil.BackColor = System.Drawing.Color.White;
            this.tbhasil.BorderColorFocused = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(163)))), ((int)(((byte)(233)))));
            this.tbhasil.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(163)))), ((int)(((byte)(233)))));
            this.tbhasil.BorderColorMouseHover = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(163)))), ((int)(((byte)(233)))));
            this.tbhasil.BorderThickness = 3;
            this.tbhasil.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbhasil.Enabled = false;
            this.tbhasil.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbhasil.ForeColor = System.Drawing.Color.Black;
            this.tbhasil.isPassword = false;
            this.tbhasil.Location = new System.Drawing.Point(4, 7);
            this.tbhasil.Margin = new System.Windows.Forms.Padding(4);
            this.tbhasil.Name = "tbhasil";
            this.tbhasil.Size = new System.Drawing.Size(439, 42);
            this.tbhasil.TabIndex = 0;
            this.tbhasil.Text = "0";
            this.tbhasil.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tbhasil.OnValueChanged += new System.EventHandler(this.tbhasil_OnValueChanged);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(133)))), ((int)(((byte)(233)))));
            this.panel3.Controls.Add(this.Label4);
            this.panel3.Controls.Add(this.Label1);
            this.panel3.Controls.Add(this.richTextBox1);
            this.panel3.Controls.Add(this.monthCalendar1);
            this.panel3.Location = new System.Drawing.Point(447, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(253, 458);
            this.panel3.TabIndex = 2;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("GeosansLight", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.ForeColor = System.Drawing.Color.White;
            this.Label4.Location = new System.Drawing.Point(52, 28);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(0, 39);
            this.Label4.TabIndex = 2;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(9, 266);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(54, 13);
            this.Label1.TabIndex = 44;
            this.Label1.Text = "Notepad";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(11, 281);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(227, 166);
            this.richTextBox1.TabIndex = 43;
            this.richTextBox1.Text = "";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(11, 95);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 42;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(695, 457);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "D-Calculate 1.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImageButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImageButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clsamadengan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clkali)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clminus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clplus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clbagi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cldot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clpersen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clhapus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clclear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clplusminus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cl6)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuMetroTextbox tbhasil;
        private Bunifu.Framework.UI.BunifuImageButton cl3;
        private Bunifu.Framework.UI.BunifuImageButton cl4;
        private Bunifu.Framework.UI.BunifuImageButton cl1;
        private Bunifu.Framework.UI.BunifuImageButton cl0;
        private Bunifu.Framework.UI.BunifuImageButton cl2;
        private Bunifu.Framework.UI.BunifuImageButton cl5;
        private Bunifu.Framework.UI.BunifuImageButton cl6;
        private System.Windows.Forms.Panel panel3;
        private Bunifu.Framework.UI.BunifuImageButton clplusminus;
        private Bunifu.Framework.UI.BunifuImageButton cl8;
        private Bunifu.Framework.UI.BunifuImageButton cl9;
        private Bunifu.Framework.UI.BunifuImageButton cl7;
        private Bunifu.Framework.UI.BunifuImageButton clclear;
        private Bunifu.Framework.UI.BunifuImageButton cldot;
        private Bunifu.Framework.UI.BunifuImageButton clpersen;
        private Bunifu.Framework.UI.BunifuImageButton clhapus;
        private Bunifu.Framework.UI.BunifuImageButton clsamadengan;
        private Bunifu.Framework.UI.BunifuImageButton clkali;
        private Bunifu.Framework.UI.BunifuImageButton clminus;
        private Bunifu.Framework.UI.BunifuImageButton clplus;
        private Bunifu.Framework.UI.BunifuImageButton clbagi;
        private System.Windows.Forms.Button Sin;
        private System.Windows.Forms.Button Tan;
        private System.Windows.Forms.Button Log;
        private System.Windows.Forms.Button Cos;
        private Bunifu.Framework.UI.BunifuImageButton ImageButton2;
        private Bunifu.Framework.UI.BunifuImageButton ImageButton1;
        private Bunifu.Framework.UI.BunifuCustomLabel Label1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Button button1;
        private Bunifu.Framework.UI.BunifuCustomLabel Label2;
        private Bunifu.Framework.UI.BunifuCustomLabel Label3;
        private Bunifu.Framework.UI.BunifuCustomLabel Label4;
        private System.Windows.Forms.Timer timer1;
        private Bunifu.Framework.UI.BunifuCustomLabel Label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuCircleProgressbar CircleProgressbar1;
    }
}

