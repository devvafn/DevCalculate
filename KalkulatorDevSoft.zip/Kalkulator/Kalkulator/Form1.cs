using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Kalkulator
{
    public partial class Form1 : Form
    {
        double FirstNumber; //variable number pertama yang di input 
        string Operation; //variable operasi perhitungan

        public Form1()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cl1_Click(object sender, EventArgs e)
        {
            if (tbhasil.Text == "0" && tbhasil.Text != null) //jika tbhasil == 0 dan tbhasil juga == null atau kosong maka tbhasil akan di isi 1 
            {
                tbhasil.Text = "1";
            }
            else
            {
                tbhasil.Text = tbhasil.Text + "1"; //jika tidak == 0 maka nomer yang sudah ada (tbhasil) di tambah + 1
            }
        }

        private void cl0_Click(object sender, EventArgs e)
        {
                tbhasil.Text = tbhasil.Text + "0";
        }

        private void cl2_Click(object sender, EventArgs e)
        {
            if (tbhasil.Text == "0" && tbhasil.Text != null)
            {
                tbhasil.Text = "2";
            }
            else
            {
                tbhasil.Text = tbhasil.Text + "2";
            }
        }

        private void cl3_Click(object sender, EventArgs e)
        {
            if (tbhasil.Text == "0" && tbhasil.Text != null)
            {
                tbhasil.Text = "3";
            }
            else
            {
                tbhasil.Text = tbhasil.Text + "3";
            }
        }

        private void cl4_Click(object sender, EventArgs e)
        {
            if (tbhasil.Text == "0" && tbhasil.Text != null)
            {
                tbhasil.Text = "4";
            }
            else
            {
                tbhasil.Text = tbhasil.Text + "4";
            }
        }

        private void cl5_Click(object sender, EventArgs e)
        {
            if (tbhasil.Text == "0" && tbhasil.Text != null)
            {
                tbhasil.Text = "5";
            }
            else
            {
                tbhasil.Text = tbhasil.Text + "5";
            }
            
        }

        private void cl6_Click(object sender, EventArgs e)
        {
            if (tbhasil.Text == "0" && tbhasil.Text != null)
            {
                tbhasil.Text = "6";
            }
            else
            {
                tbhasil.Text = tbhasil.Text + "6";
            }
        }

        private void cl7_Click(object sender, EventArgs e)
        {
            if (tbhasil.Text == "0" && tbhasil.Text != null)
            {
                tbhasil.Text = "7";
            }
            else
            {
                tbhasil.Text = tbhasil.Text + "7";
            }
        }

        private void cl8_Click(object sender, EventArgs e)
        {
            if (tbhasil.Text == "0" && tbhasil.Text != null)
            {
                tbhasil.Text = "8";
            }
            else
            {
                tbhasil.Text = tbhasil.Text + "8";
            }
        }

        private void cl9_Click(object sender, EventArgs e)
        {
            if (tbhasil.Text == "0" && tbhasil.Text != null)
            {
                tbhasil.Text = "9";
            }
            else
            {
                tbhasil.Text = tbhasil.Text + "9";
            }
        }

        private void clplus_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(tbhasil.Text); //variable firstnumber di convert ke double yang ada di tbhasil
            tbhasil.Text = "0"; // ketika di klik jumlah plus maka tbhasil akan menjadi nol lagi
            Operation = "+"; //dan operiasi nya adalah +
        }

        private void clsamadengan_Click(object sender, EventArgs e)
        {
            double SecondNumber; //variable secondnumber untuk inputan tb hasil yang kedua
            double Result; //variable result untuk hasil akhir dari penjumlahan akhir di samadengan

            SecondNumber = Convert.ToDouble(tbhasil.Text); //variable seconnumber di convert ke double

            if (Operation == "+") //operasi untuk hitungan tambah
            {
                Result = (FirstNumber + SecondNumber);
                tbhasil.Text = Convert.ToString(Result);
                FirstNumber = Result;
            }
            if (Operation == "-") //operasi untuk hitungan pengurangan
            {
                Result = (FirstNumber - SecondNumber);
                tbhasil.Text = Convert.ToString(Result);
                FirstNumber = Result;
            }
            if (Operation == "*") //operasi untuk hitungan perkalian
            {
                Result = (FirstNumber * SecondNumber);
                tbhasil.Text = Convert.ToString(Result);
                FirstNumber = Result;
            }
            if (Operation == "/") //operasi untuk hitungan tambah pembagian
            {
                if (SecondNumber == 0)
                {
                    tbhasil.Text = "Cannot divide by zero";

                }
                else
                {
                    Result = (FirstNumber / SecondNumber);
                    tbhasil.Text = Convert.ToString(Result);
                    FirstNumber = Result;
                }
            }
            if (Operation == "%") //operasi untuk hitungan percen
            {
                Result = (FirstNumber % SecondNumber);
                tbhasil.Text = Convert.ToString(Result);
                FirstNumber = Result;
            }
        }

        private void cldot_Click(object sender, EventArgs e)
        {
            tbhasil.Text = tbhasil.Text + ".";
        }

        private void clclear_Click(object sender, EventArgs e)
        {
            tbhasil.Text = "0";
        }

        private void clbagi_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(tbhasil.Text);
            tbhasil.Text = "0";
            Operation = "/";
        }

        private void clkali_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(tbhasil.Text);
            tbhasil.Text = "0";
            Operation = "*";
        }

        private void clminus_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(tbhasil.Text);
            tbhasil.Text = "0";
            Operation = "-";
        }

        private void clplusminus_Click(object sender, EventArgs e)
        {
            if (!tbhasil.Text.Contains("-"))

                tbhasil.Text = "-" + tbhasil.Text;

            else

                tbhasil.Text = tbhasil.Text.Trim('-');
        }

        private void clpersen_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(tbhasil.Text);
            tbhasil.Text = "0";
            Operation = "%";
        }

        private void Sin_Click(object sender, EventArgs e)
        {
            tbhasil.Text = Convert.ToString(System.Math.Sin((Convert.ToDouble(System.Math.PI) / 180) * (Convert.ToDouble(tbhasil.Text)))); //fungsi untuk perhitungan SIN
        }

        private void Cos_Click(object sender, EventArgs e)
        {
            tbhasil.Text = Convert.ToString(System.Math.Cos((Convert.ToDouble(System.Math.PI) / 180) * (Convert.ToDouble(tbhasil.Text)))); //fungsi untuk perhitungan COS
        }

        private void Log_Click(object sender, EventArgs e)
        {
            tbhasil.Text = Convert.ToString(System.Math.Log10(Convert.ToDouble(tbhasil.Text))); //fungsi untuk perhitungan Log
        }

        private void Tan_Click(object sender, EventArgs e)
        {
            tbhasil.Text = Convert.ToString(System.Math.Tan((Convert.ToDouble(System.Math.PI) / 180) * (Convert.ToDouble(tbhasil.Text)))); //fungsi untuk perhitungan Tan
        }

        

        private void tbhasil_OnValueChanged(object sender, EventArgs e)
        {
  
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Clipboard.SetText(tbhasil.Text); //untuk ketika di klik di simpan ke clipboard atau di copy
            MessageBox.Show("Succes Copy","Copy"); //pesan box setelah button di klik 
        }
        

        private void timer1_Tick(object sender, EventArgs e)
        {
            Label4.Text = DateTime.Now.ToString("H:mm:ss"); //fungsi untuk menampilkan jam
        }

        private void ImageButton1_Click_1(object sender, EventArgs e)
        {
            tbhasil.Text = (Math.Sqrt(double.Parse(tbhasil.Text))).ToString(); //fungsi untuk perhitungan Akar
        }

        private void ImageButton2_Click_1(object sender, EventArgs e)
        {
            tbhasil.Text = Convert.ToString(Convert.ToInt32(tbhasil.Text) * Convert.ToInt32(tbhasil.Text)); //fungsi untuk perhitungan kuadrat 
        }
    }
}
